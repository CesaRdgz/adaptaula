import json,glob,re,subprocess
S='/tmp/claude-0/-home-claude/a3e52a9f-9cae-56f9-b3b8-faa4c517708d/scratchpad/ev.pdf'
def nums(t): return set(re.findall(r'\d[\d.,]*\d|\d',t.replace(' ',' ')))
for f in sorted(glob.glob('catalogo/*.examen.json')):
    x=json.load(open(f)); j=json.dumps(x,ensure_ascii=False)
    j=re.sub(r'"(src|anchoMm|numero|formato|paginas|tema|trimestre)":\s*("[^"]*"|[\d.]+|\[[^\]]*\])','',j)
    pg=x['fuente']['paginas']; off=1 if pg[0]>=42 else 0
    src=''.join(subprocess.run(['pdftotext','-f',str(p+off),'-l',str(p+off),S,'-'],capture_output=True,text=True).stdout for p in pg)
    if x['id']=='t09-A': src+=subprocess.run(['pdftotext','-f','42','-l','42',S,'-'],capture_output=True,text=True).stdout
    a,b=nums(src),nums(j)
    falta=sorted(n for n in a-b if not re.fullmatch(r'\d{1,2}',n)); sobra=sorted(b-a)
    print(x['id'],'| falta:',falta,'| sobra:',sobra)
