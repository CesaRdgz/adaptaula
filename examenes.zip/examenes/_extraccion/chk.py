import sys,glob
from PIL import Image,ImageDraw
fs=sorted(sum([glob.glob(f'catalogo/imagenes/{p}-*.png') for p in sys.argv[1:]],[]))
ims=[Image.open(f).convert('RGB') for f in fs]
s=0.5
ims=[i.resize((int(i.width*s),int(i.height*s))) for i in ims]
# two columns layout
col=[[],[]];hs=[0,0]
for i,f in zip(ims,fs):
    k=0 if hs[0]<=hs[1] else 1; col[k].append((i,f)); hs[k]+=i.height+22
W=max([i.width for i in ims]+[10]);c=Image.new('RGB',(2*W+20,max(hs)),'white');d=ImageDraw.Draw(c)
for k in (0,1):
    y=0
    for i,f in col[k]:
        d.text((k*(W+20),y),f.split('/')[-1],fill='red');c.paste(i,(k*(W+20),y+12));d.rectangle([k*(W+20),y+12,k*(W+20)+i.width,y+12+i.height],outline='blue');y+=i.height+22
c.save('/tmp/claude-0/-home-claude/a3e52a9f-9cae-56f9-b3b8-faa4c517708d/scratchpad/chk.png');print(c.size)
