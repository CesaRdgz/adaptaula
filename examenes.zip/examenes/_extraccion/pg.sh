#!/bin/bash
for p in "$@"; do echo "=========== PAGE $p"; pdftotext -layout -f $p -l $p /tmp/claude-0/-home-claude/a3e52a9f-9cae-56f9-b3b8-faa4c517708d/scratchpad/ev.pdf - | sed 's/  \+/  /g' | grep -v "^\s*$" | grep -v "Material fotocopiable\|MATEMÁTICAS 4\|PRIMARIA$\|Santillana Educación"; done
