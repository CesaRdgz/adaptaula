"""Helpers para definir exámenes extraídos del cuaderno Evaluación 360º y generar sus .examen.json."""
import json, os
from PIL import Image

HI = '/tmp/claude-0/-home-claude/a3e52a9f-9cae-56f9-b3b8-faa4c517708d/scratchpad/hi/p-{:02d}.png'
OUT = '/home/claude/extraccion/catalogo'
DOC = 'Evaluación 360º Matemáticas 4 (Santillana)'
os.makedirs(OUT + '/imagenes', exist_ok=True)

_actual = {}

def img(pagina, caja, alt, medir=False):
    """Recorta una figura de la página (caja en fracciones x0,y0,x1,y1) y devuelve el bloque imagen."""
    ex = _actual['id']; _actual['n'] = _actual.get('n', 0) + 1
    nombre = f"imagenes/{ex}-{_actual['n']:02d}.png"
    im = Image.open(HI.format(pagina)); w, h = im.size
    x0, y0, x1, y1 = caja
    c = im.crop((int(x0*w), int(y0*h), int(x1*w), int(y1*h)))
    c = c.resize((max(1, c.width*3//4), max(1, c.height*3//4)), Image.LANCZOS)  # 150 ppp
    c.save(f'{OUT}/{nombre}', optimize=True)
    b = {'tipo': 'imagen', 'src': nombre, 'alt': alt, 'anchoMm': round((x1 - x0) * 210, 1)}
    if medir: b['medir'] = True
    return b

# bloques
def titulo(t): return {'tipo': 'titulo', 'texto': t}
def texto(t): return {'tipo': 'texto', 'texto': t}
def lista(*i): return {'tipo': 'lista', 'items': list(i)}
def tabla(cab, *filas):
    t = {'filas': [list(f) for f in filas]}
    if cab: t['cabecera'] = list(cab)
    return {'tipo': 'tabla', 'tabla': t}

# apartados (respuesta)
def _a(t, r, ctx=None):
    a = {'texto': t, 'respuesta': r}
    if ctx: a['contexto'] = ctx if isinstance(ctx, list) else [ctx]
    return a
def problema(t, ctx=None): return _a(t, {'tipo': 'problema'}, ctx)
def calculo(t, ctx=None): return _a(t, {'tipo': 'calculo'}, ctx)
def lineas(t, n=2, ctx=None): return _a(t, {'tipo': 'lineas', 'lineas': n}, ctx)
def corta(t, ctx=None): return _a(t, {'tipo': 'corta'}, ctx)
def dibujo(t='', ctx=None): return _a(t, {'tipo': 'dibujo'}, ctx)
def completar(plantilla, t='', ctx=None): return _a(t, {'tipo': 'completar', 'plantilla': plantilla}, ctx)
def elegir(t, opciones, ctx=None): return _a(t, {'tipo': 'elegir', 'opciones': list(opciones)}, ctx)
def unir(t, izq, der, ctx=None): return _a(t, {'tipo': 'unir', 'izquierda': list(izq), 'derecha': list(der)}, ctx)
def rellenar(t, cab, *filas, ctx=None):
    tb = {'filas': [list(f) for f in filas]}
    if cab: tb['cabecera'] = list(cab)
    return _a(t, {'tipo': 'tabla', 'tabla': tb}, ctx)

def ej(enunciado, *apartados, ctx=None):
    e = {'enunciado': enunciado, 'apartados': list(apartados)}
    if ctx: e['contexto'] = ctx if isinstance(ctx, list) else [ctx]
    return e

def empezar(id):
    _actual.clear(); _actual['id'] = id

def examen(id, titulo_, tipo, paginas, ejercicios, contexto=None, tema=None, trimestre=None, modelo=None):
    assert _actual.get('id') == id, f'llama a empezar("{id}") antes de recortar imágenes'
    for i, e in enumerate(ejercicios, 1):
        e['numero'] = i
    x = {'formato': 1, 'id': id, 'titulo': titulo_, 'tipo': tipo}
    if tema: x['tema'] = tema
    if trimestre: x['trimestre'] = trimestre
    if modelo: x['modelo'] = modelo
    x.update({'curso': '4.º Primaria', 'area': 'Matemáticas'})
    if contexto: x['contexto'] = contexto
    x['ejercicios'] = [{'numero': e['numero'], **{k: v for k, v in e.items() if k != 'numero'}} for e in ejercicios]
    x['fuente'] = {'documento': DOC, 'paginas': paginas}
    with open(f'{OUT}/{id}.examen.json', 'w', encoding='utf-8') as f:
        json.dump(x, f, ensure_ascii=False, indent=2)
    print('ok', id, len(ejercicios), 'ejercicios')

def cuadriculas_decimal(alt):
    """Dibuja dos cuadrículas 10 × 10 limpias (4 décimas / 65 centésimas). La del original sale tapada por una foto al convertir."""
    from PIL import ImageDraw, ImageFont
    ex = _actual['id']; _actual['n'] = _actual.get('n', 0) + 1
    nombre = f"imagenes/{ex}-{_actual['n']:02d}.png"
    W, H, c, m = 1250, 300, 22, 30  # 150 ppp aprox.
    im = Image.new('RGB', (W, H), 'white'); d = ImageDraw.Draw(im)
    try: f = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 28)
    except OSError: f = ImageFont.load_default()
    for x0, rot, eq in ((m, '4 décimas', '4 d = —— = ——'), (W // 2 + m, '65 centésimas', '65 c = —— = ——')):
        d.text((x0, 5), rot, fill='black', font=f)
        for i in range(11):
            d.line([(x0 + i * c, 50), (x0 + i * c, 50 + 10 * c)], fill='black', width=2 if i in (0, 10) else 1)
            d.line([(x0, 50 + i * c), (x0 + 10 * c, 50 + i * c)], fill='black', width=2 if i in (0, 10) else 1)
        d.text((x0 + 10 * c + 25, 50 + 4 * c), eq, fill='black', font=f)
    im.save(f'{OUT}/{nombre}', optimize=True)
    return {'tipo': 'imagen', 'src': nombre, 'alt': alt, 'anchoMm': 170}
