from ext import *

CTX = [titulo('Relojes inteligentes'),
       tabla(['Modelo', 'Rectangular', 'Circular', 'Ovalado', 'Cuadrado'],
             ['Precio', '99,78 €', '246,40 €', '52,05 €', '108,64 €'],
             ['Longitud', '2 dm', '15 cm', '1 dm y 7 cm', '135 mm'],
             ['Peso', '416 mg', '51 cg', '3 dg', '300 g y 8 mg'])]

EJ1 = lambda: ej('Observa las características de los relojes inteligentes y ordena de mayor a menor.',
                 lineas('Sus precios.', 2), lineas('Sus longitudes.', 2), lineas('Sus pesos.', 2))

def ej2(ultima):
    return ej('Lee y calcula el precio final del reloj circular en cada una de estas tres tiendas.',
              problema('Tecnoloj: rebaja de 85,46 €.'),
              problema('Horadía: 12,08 € más que el precio original.'),
              problema('Retecno (tienda de segunda mano): a mitad de precio.'),
              ultima)

VALERIA = 'El reloj de Valeria indica que hoy lleva dados 1.475 pasos. Si con un paso recorre 60 cm, ¿cuántos metros lleva recorridos en total?'

empezar('tr3-B')
examen('tr3-B', 'Evaluación del tercer trimestre · Modelo B', 'trimestre', [62, 63], trimestre=3, modelo='B', contexto=CTX, ejercicios=[
  EJ1(),
  ej2(lineas('Escribe la descomposición y lectura de los precios finales que has calculado.', 6)),
  ej('Dibuja la hora que marcaría este reloj si se configura con el modo reloj de agujas. Después, escribe cómo se leen las horas.',
     dibujo('', ctx=img(64, (0.13, 0.135, 0.90, 0.235), 'Dos relojes digitales (07:55 y 18:20), cada uno con un reloj de agujas vacío al lado.')),
     completar('07:55 → Son las ___'),
     completar('18:20 → Son las ___')),
  ej('Lee y resuelve.',
     problema('Rosa tiene configurada una alarma a las 08:25 de la mañana y otra a las 15:40. ¿Cuánto tiempo hay entre ellas? Exprésalo en segundos.'),
     problema('Adrián puso el cronómetro y al pararlo marcaba 754 segundos. ¿Cuántos minutos y segundos son?')),
  ej('Piensa y contesta.',
     problema(VALERIA),
     problema('El reloj cuadrado puede registrar el peso corporal. Hace un año, Álvaro registró 78.500 g, y este año, 77.300 g. '
              '¿Cuántos kilogramos y hectogramos de diferencia hay entre ambos pesos?'),
     problema('Santiago va registrando en su reloj las cantidades de agua que va bebiendo a lo largo del día. De momento ha bebido 350 ml, 4 dl, 45 cl '
              'y un cuarto de litro. ¿Cuántos litros, decilitros y centilitros ha bebido en total ya?')),
])

empezar('tr3-A')
examen('tr3-A', 'Evaluación del tercer trimestre · Modelo A', 'trimestre', [64, 65], trimestre=3, modelo='A', contexto=CTX, ejercicios=[
  EJ1(),
  ej2(problema('Escribe cuánto dinero le devolverán a Jaime si al comprar el reloj en la tienda en la que sale más barato, paga con 7 billetes de 20 € y una moneda de 50 cts.')),
  ej('Observa las alarmas y resuelve.',
     problema('Si ahora son las 08:04, ¿cuántas horas y minutos faltan para que suene cada alarma?'),
     problema('¿Cuánto tiempo transcurrirá entre ellas? Exprésalo en segundos.'),
     problema('Adrián ha puesto el cronómetro y al pararlo marcaba 11.310 s. ¿Cuántas horas, minutos y segundos son?'),
     ctx=texto('Rosa tiene configuradas estas alarmas: 08:25 y 15:42.')),
  ej('Lee y resuelve.',
     problema(VALERIA),
     problema('El reloj cuadrado puede registrar el peso corporal. Hace un año, Álvaro registró 78.580 g, y este año, 77.300 g. '
              'Descompón la diferencia de los pesos utilizando el mayor número de unidades posible.'),
     problema('Sara va registrando en su reloj las cantidades de agua que bebe a lo largo del día. De momento ha bebido 350 ml, 4 dl, 45 cl '
              'y un cuarto de litro. ¿Cuántos decilitros y centilitros le faltan para tomar 2 ℓ?')),
])
