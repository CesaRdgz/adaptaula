from ext import *

CTX = [titulo('Cosechando aceitunas'),
       texto('Masa de aceituna cosechada y aceite obtenido por finca esta temporada:'),
       tabla(['Finca', 'Masa de aceituna', 'Aceite obtenido'],
             ['La Veguilla', '76 q', '19 hl'], ['Mirablanca', '21 t', '3 kl'],
             ['Los Cármenes', '30.000 hg', '50.000 cl'], ['Catacena', '9.000 kg', '13.000 dl'])]

def ej1(palabra):
    return ej('Observa los datos y ordena las fincas según se indica. Después, contesta.',
              lineas('De menor a mayor masa de aceituna cosechada.', 3),
              lineas(f'De menor a mayor {palabra} de aceite obtenido esta temporada.', 3))

def ej2(segunda):
    return ej('Lee y responde.',
              *[problema(c) for c in ['21 kg', segunda, '600 hg y 9 dag', '27.000 mg']],
              ctx=texto('Cada aceituna de la finca Mirablanca pesa unos 300 cg. ¿Cuántas aceitunas hay en estas cantidades?'))

def envases(p, primero):
    return img(p, (0.11, 0.115, 0.85, 0.29), f'Cinco envases de aceite: A ({primero}), B (2.000 ml), C (1 ℓ), D (75 cl) y E (50 dl).')

ORDENAR = lambda p, primero: lineas('Ordena los envases de mayor a menor capacidad.', 2, ctx=envases(p, primero))
DECALITROS = lambda: problema('¿Cuántos decalitros de aceite hay en 1.000 botellitas de 25 cl cada una?')
OLIVOS = lambda: problema('En la finca Los Cármenes, de cada olivo han obtenido 25.000 g de aceitunas. ¿Cuántos olivos hay en la finca?')

empezar('t12-B')
examen('t12-B', 'Prueba de evaluación 12 · Modelo B', 'tema', [50, 51], tema=12, modelo='B', contexto=CTX, ejercicios=[
  ej1('cantidad'),
  ej2('3.000 mg y 300 cg'),
  ej('Observa los envases y ordénalos de mayor a menor capacidad.',
     ORDENAR(52, '25 cl'), DECALITROS(),
     problema('¿Cuántas garrafas de 5 ℓ se pueden rellenar con 812 hl de aceite?'),
     problema('Del aceite obtenido en la finca Mirablanca se han vendido 108 garrafas de 5 ℓ y 48 botellas de 75 cl. ¿Cuánto se ha vendido ya?')),
  ej('Lee y resuelve.', OLIVOS(),
     problema('¿Cuántos kilos de aceituna han necesitado en la finca La Veguilla para obtener 1 ℓ de aceite?')),
])

empezar('t12-A')
examen('t12-A', 'Prueba de evaluación 12 · Modelo A', 'tema', [52, 53], tema=12, modelo='A', contexto=CTX, ejercicios=[
  ej1('capacidad'),
  ej2('36.000 mg, 900 cg y 60 dg'),
  ej('Observa los envases y ordénalos de mayor a menor capacidad.',
     ORDENAR(54, 'un cuarto de litro'), DECALITROS(),
     problema('¿Cuántas botellas de 75 cl se pueden rellenar con 82 dal de aceite? ¿Sobrará aceite? ¿En qué tipo de recipiente podrías envasarlo?'),
     problema('Del aceite obtenido en la finca Mirablanca se han vendido 108 garrafas de 5 ℓ, 144 botellas de 25 cl y 10 de 2 ℓ. ¿Cuánto aceite queda por vender?')),
  ej('Lee y resuelve.', OLIVOS(),
     problema('En la finca La Veguilla, para obtener 1 ℓ de aceite, han necesitado 4 kg de aceituna. ¿Es cierto?')),
])
