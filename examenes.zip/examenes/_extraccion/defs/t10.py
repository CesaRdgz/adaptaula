from ext import *

CTX = [titulo('Viajando en tren'),
       texto('Frecuencia de paso de trenes según la franja horaria y su línea:'),
       tabla(['Franja horaria', 'Línea 1', 'Línea 2', 'Línea 3'],
             ['07:00 – 09:30', '35 min', '17 min', '50 min'],
             ['09:30 – 16:30', '45 min', '25 min', '1 h y 3 min'],
             ['16:30 – 23:45', '28 min', '15 min', '55 min'])]

def ej1(ultima_hora, relojes, *mas):
    return ej('Observa la hora a la que llegaron estos trenes y escribe a qué hora pasarán los tres siguientes. Después, contesta.',
              rellenar('', ['Línea', 'Llegó a las', 'Siguiente', 'Siguiente', 'Siguiente'],
                       ['Línea 1', '16:40', '', '', ''], ['Línea 2', '10:55', '', '', ''],
                       ['Línea 3', '10:05', '', '', ''], ['Línea 3', ultima_hora, '', '', '']),
              dibujo(relojes[0], ctx=relojes[1]), *mas)

def ej3(pregunta, segundos):
    return ej('Fíjate en la frecuencia de estos trenes y averigua a qué franja horaria y línea corresponden. Después, contesta.',
              rellenar('', ['Frecuencia', 'Franja horaria', 'Línea'], ['1.680 s', '', ''], ['3.780 s', '', ''], ['900 s', '', '']),
              problema(pregunta),
              problema(f'El trayecto de un tren de alta velocidad ha durado {segundos} segundos. ¿Cuántas horas y minutos son?'))

EJ4 = lambda: ej('Observa los datos y calcula el número de veces que se revisa la mecánica de cada tipo de tren en un lustro.',
                 problema('Línea 1: 1 vez al trimestre.'), problema('Línea 2: 3 veces al semestre.'), problema('Línea 3: 2 veces al cuatrimestre.'))

TARIFAS = [lista('Línea 1: 2,45 €', 'Línea 2: 3,26 €', 'Línea 3: 1,90 €'),
           texto('Precios por zona. Todas las zonas de cada línea cuestan igual.')]
ALVARO = 'Álvaro debe atravesar 2 zonas de la línea 2 para llegar a su destino. Si para pagar tiene un billete de 5 €, 4 monedas de 20 cts. y 8 monedas de 10 cts., '

empezar('t10-B')
examen('t10-B', 'Prueba de evaluación 10 · Modelo B', 'tema', [42, 43], tema=10, modelo='B', contexto=CTX, ejercicios=[
  ej1('07:00', ('Representa en estos relojes de agujas las siguientes horas: 16:40 y 10:05.',
                img(43, (0.52, 0.615, 0.87, 0.71), 'Dos relojes de agujas vacíos.')),
      problema('¿Cuántos minutos hay en cada franja horaria?')),
  ej('Lee y contesta.',
     problema('Un tren va retrasado 2 h y 35 min. Si tenía que llegar a la siguiente estación a las 14:54, ¿a qué hora llegará en realidad?'),
     problema('Un tren ha salido a las 9 y 34 de la noche. ¿A qué hora llegará a la siguiente estación si el trayecto entre ellas dura 46 minutos?')),
  ej3('Por un problema en las vías, no pasaron trenes durante 7 horas y 20 minutos. ¿Cuántos minutos son?', '16.080'),
  EJ4(),
  ej('Observa las tarifas de cada línea y contesta.',
     problema(ALVARO + '¿tendrá suficiente dinero?'),
     problema('Inma va a coger la línea 1 por 2 zonas y, después, la línea 3 para atravesar 1 zona más. ¿Cuánto pagará en total?'),
     ctx=TARIFAS),
])

empezar('t10-A')
examen('t10-A', 'Prueba de evaluación 10 · Modelo A', 'tema', [44, 45], tema=10, modelo='A', contexto=CTX, ejercicios=[
  ej1('08:40', ('Representa en un reloj de agujas las siguientes horas: 16:40 y 10:05.',
                img(45, (0.52, 0.595, 0.87, 0.688), 'Dos relojes de agujas vacíos.'))),
  ej('Lee y contesta.',
     problema('¿A qué hora llegó Violeta a la estación?'),
     problema('¿A qué hora llegó el tren en el que subió Violeta?'),
     problema('¿A qué hora bajó del tren Violeta?'),
     problema('¿A qué hora cogió Hugo el tren en Collado Pequeño?'),
     ctx=[texto('Violeta llegó a la estación de Collado Pequeño 9 minutos antes de que llegara el tren de la línea 2. El tren tenía que haber llegado '
                'a las 09:05, pero iba retrasado 6 minutos. Tras un trayecto de 1 h y 38 minutos, Violeta se bajó del tren.'),
          texto('Hugo cogió el siguiente tren de la línea 2 en Collado Pequeño.')]),
  ej3('Por un problema en las vías, no pasaron trenes en 7 horas y 20 minutos. ¿Cuántos segundos son?', '16.085'),
  EJ4(),
  ej('Observa las tarifas de cada línea y contesta.',
     problema(ALVARO + '¿cuánto dinero le falta o le sobra?'),
     problema('Inma va a coger la línea 1 por 2 zonas y, después, la línea 3 para atravesar 1 zona más. ¿Cuánto pagará en total por el viaje de ida y vuelta?'),
     ctx=TARIFAS),
])
