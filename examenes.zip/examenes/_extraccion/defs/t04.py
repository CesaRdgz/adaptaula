from ext import *

def ctx(p):
    return [titulo('Observando vidrieras'), texto('¡Cuántos polígonos!'),
            texto('Las vidrieras se hacen con trocitos de vidrio de colores. Esta vidriera está compuesta por cristales con formas de polígonos. ¡Vamos a clasificarlos!'),
            img(p, (0.10, 0.145, 0.59, 0.365), 'Vidriera de colores formada por cristales con forma de polígonos.')]

def cristales(p):
    y0, y1 = {18: (0.443, 0.555), 20: (0.43, 0.55)}[p]
    return img(p, (0.13, y0, 0.83, y1), 'Seis cristales poligonales de la vidriera, cada uno con una flecha para escribir su clasificación.')

def trozos(p, y0, y1):
    return img(p, (0.12, y0, 0.84, y1), 'Tres trozos de la vidriera formados por varios polígonos, rotulados «Ángulo agudo», «Ángulo obtuso» y «Ángulo recto».')

empezar('t04-B')
examen('t04-B', 'Prueba de evaluación 4 · Modelo B', 'tema', [18, 19], tema=4, modelo='B', contexto=ctx(18), ejercicios=[
  ej('Observa la vidriera y clasifica los siguientes cristales poligonales. Después, contesta.',
     dibujo('Escribe junto a cada cristal su clasificación.', ctx=cristales(18)),
     lineas('¿Qué tipo de cuadrilátero no está en la vidriera? Clasifícalo de todas las formas posibles y describe sus características.', 3),
     lineas('¿Cuál es el único tipo de triángulo que hay? Clasifícalo según sus ángulos y según sus lados.', 3)),
  ej('Indica qué polígono forman los siguientes trozos de la vidriera y marca sobre cada uno de ellos un ángulo del tipo indicado.',
     dibujo('', ctx=trozos(18, 0.77, 0.94))),
  ej('Traza algunas diagonales en este polígono y colorea para formar una vidriera. Después, contesta.',
     dibujo('', ctx=img(19, (0.63, 0.085, 0.92, 0.28), 'Heptágono gris.')),
     lineas('¿Es un heptágono regular? ¿Por qué?', 2),
     lineas('Clasifica ahora los polígonos que se han formado en su interior de todas las formas posibles.', 3)),
  ej('Observa y calcula el perímetro de los siguientes cristales de la vidriera sabiendo que las medidas están en milímetros.',
     calculo('Triángulo de lados 17, 17 y 24 mm.'),
     calculo('Paralelogramo de lados 16, 29, 12 y 18 mm.'),
     calculo('Paralelogramo de lados 18, 11, 18 y 11 mm.'),
     ctx=img(19, (0.15, 0.44, 0.86, 0.55), 'Tres cristales con sus medidas en milímetros: un triángulo (17, 17, 24), un paralelogramo (16, 29, 12, 18) y otro paralelogramo (18, 11, 18, 11).')),
  ej('Calcula el área de las siguientes piezas de vidrio.',
     calculo('', ctx=img(19, (0.13, 0.73, 0.80, 0.885), 'Piezas de vidrio dibujadas sobre una cuadrícula.'))),
])

empezar('t04-A')
examen('t04-A', 'Prueba de evaluación 4 · Modelo A', 'tema', [20, 21], tema=4, modelo='A', contexto=ctx(20), ejercicios=[
  ej('Observa la vidriera y clasifica los siguientes cristales. Después, contesta.',
     dibujo('Escribe junto a cada cristal su clasificación.', ctx=cristales(20)),
     lineas('¿Qué tipo de cuadrilátero no está en la vidriera? Clasifícalo de todas las formas posibles y describe sus características.', 3),
     lineas('¿Se podría decir que un rombo es un cuadrado? En caso afirmativo, ¿faltaría algún tipo de cuadrilátero en la vidriera?', 3)),
  ej('Indica qué polígono forman los siguientes trozos de la vidriera y marca sobre cada uno de ellos el ángulo indicado. Mídelo con transportador de ángulos y anota sus medidas.',
     dibujo('', ctx=img(20, (0.12, 0.78, 0.84, 0.955), 'Tres trozos de la vidriera formados por varios polígonos, rotulados «Ángulo agudo», «Ángulo obtuso» y «Ángulo recto».', medir=True))),
  ej('Traza todas las diagonales de este polígono para formar una vidriera. Después, contesta.',
     dibujo('', ctx=img(21, (0.63, 0.085, 0.92, 0.275), 'Pentágono gris.')),
     lineas('¿Qué tipo de polígono delimita la vidriera? ¿Cuántas diagonales tiene en total?', 2),
     lineas('¿Cómo son los triángulos que se han formado? Clasifícalos.', 2),
     lineas('¿Qué otro polígono aparece? Clasifícalo.', 2)),
  ej('Mide en milímetros y calcula el perímetro de estos cristales de la vidriera.',
     calculo('', ctx=img(21, (0.15, 0.505, 0.86, 0.59), 'Tres cristales sin medidas: un triángulo y dos paralelogramos.', medir=True))),
  ej('Calcula el área de las siguientes piezas de vidrio.',
     calculo('', ctx=img(21, (0.13, 0.74, 0.80, 0.89), 'Piezas de vidrio dibujadas sobre una cuadrícula.'))),
])
