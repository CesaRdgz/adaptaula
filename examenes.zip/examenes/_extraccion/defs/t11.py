from ext import *

CTX = [titulo('Playas maravillosas'),
       texto('Longitud de algunas playas de España:'),
       lista('El Puntal: 45 hm', 'El Portitxol: 25.000 cm', 'Gulpiyuri: 500 dm', 'La Concha: 1.350 m',
             'Las Catedrales: 88 dam', 'El Cofete: 137 hm', 'Doñana: 28 km')]

def ej1(unidad_castilla, moro, gaviota, pregunta_pirlo):
    return ej('Observa los datos y ordena las playas de mayor a menor longitud, explicando cómo lo has hecho. Después, contesta.',
              lineas('Ordena las playas de mayor a menor longitud y explica cómo lo has hecho.', 4),
              problema('La playa de Castilla es la segunda playa más larga de España. Su longitud es mayor que la de El Cofete pero menor que la de Doñana. '
                       f'¿Cuántos {unidad_castilla} puede medir? Indica tres posibles longitudes.'),
              problema('La cala del Moro tiene una longitud menor que la playa Gulpiyuri, pero mayor que 3.000 cm. ' + moro),
              problema(f'En la roca de un acantilado de la playa de Las Catedrales hay una gaviota situada a {gaviota} mm del suelo, y una abubilla a 1.900 cm. '
                       + pregunta_pirlo))

EJ2 = lambda: ej('Expresa la longitud de estas conchas en la unidad indicada.',
                 completar('5 cm = ___ mm'), completar('70 mm = ___ cm'), completar('100 mm = ___ dm'))

def ej3(barco):
    return ej('Descompón la distancia a la que se encuentran estos elementos de la costa utilizando el mayor número de unidades posible.',
              completar('Delfín: 3.026 m = ___'), completar('Boya: 954 m = ___'), completar(f'Barco: {barco} m = ___'))

empezar('t11-B')
examen('t11-B', 'Prueba de evaluación 11 · Modelo B', 'tema', [46, 47], tema=11, modelo='B', contexto=CTX, ejercicios=[
  ej1('hectómetros', 'Indica tres posibles longitudes expresadas en decímetros.', '15.000',
      '¿A cuántos metros de altura puede estar posado un pirlo si se sitúa entre ambas aves?'),
  EJ2(),
  ej3('2.810'),
  ej('Lee y resuelve estos problemas con medidas de longitud.',
     problema('Situado justo en el centro del largo de la playa de El Portitxol, hay una señal informativa. ¿A cuántos decímetros de cada extremo de la playa está la señal?'),
     problema('Para realizar una limpieza de la playa de El Puntal, se ha dividido su largo en 18 zonas iguales. ¿Cuántos metros mide cada zona?'),
     problema('Elena ha recogido una concha de una longitud de 5 cm y 4 mm, y otra de 1 dm, 2 cm y 6 mm. ¿Cuánto miden las dos conchas si las coloca en fila?'),
     problema('Víctor pasea por la playa a diario. Cada día camina 5 km y 8 hm. ¿Cuántos hectómetros recorre en una semana?')),
])

empezar('t11-A')
examen('t11-A', 'Prueba de evaluación 11 · Modelo A', 'tema', [48, 49], tema=11, modelo='A', contexto=CTX, ejercicios=[
  ej1('decámetros', 'Indica tres posibles longitudes.', '17.000',
      '¿A cuántos metros y centímetros de altura puede estar posado un pirlo si se sitúa entre ambas aves?'),
  EJ2(),
  ej3('2.815'),
  ej('Lee y resuelve estos problemas con medidas de longitud.',
     problema('Situado justo a un cuarto de un extremo del largo de la playa de El Portitxol, hay una señal informativa. ¿A cuántos decímetros de cada extremo de la playa está la señal?'),
     problema('Para realizar una limpieza de la playa de El Puntal, se ha dividido su largo en 18 zonas iguales. ¿Cuánto mide cada zona?'),
     problema('Elena ha recogido una concha de una longitud de 5 cm y 4 mm, y otra de 1 dm, 2 cm y 6 mm. ¿Cuántos centímetros miden las dos conchas si las coloca en fila?'),
     problema('Víctor pasea por la playa a diario. Cada día camina 5 km y 8 hm. ¿Qué distancia recorre en una semana?')),
])
