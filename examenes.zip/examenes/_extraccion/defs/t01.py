from ext import *

CTX = [titulo('Turismo en Toledo'),
       texto('Número de personas que visitaron la provincia de Toledo en mayo:'),
       lista('En 2019: 75.787', 'En 2020: 983', 'En 2021: 34.016', 'En 2022: 48.573')]

empezar('t01-B')
examen('t01-B', 'Prueba de evaluación 1 · Modelo B', 'tema', [6, 7], tema=1, modelo='B', contexto=CTX, ejercicios=[
  ej('Descompón y escribe cómo se lee el número de personas que visitaron la provincia de Toledo en el mes de mayo en 2020, 2021 y 2022.',
     completar('983 = ___ = ___\n983 se lee ___'),
     completar('34.016 = ___ = ___\n34.016 se lee ___'),
     completar('48.573 = ___ = ___\n48.573 se lee ___')),
  ej('Lee y contesta.',
     lineas('¿En qué año hubo más visitantes en Toledo: en 2020 o en 2021? ¿Y en 2019 o en 2022?', 2),
     lineas('Ordena de menor a mayor el número de personas que visitaron la provincia de Toledo.', 2)),
  ej('Aproxima el número de personas que visitaron la provincia de Toledo al orden indicado y completa la tabla. Después, contesta.',
     rellenar('', ['', '2019', '2020', '2021', '2022'],
              ['A los millares', '', '', '', ''], ['A las centenas', '', '', '', ''], ['A las decenas', '', '', '', '']),
     lineas('¿Qué orden de aproximación te parece más adecuado para cada dato? ¿Por qué?', 3)),
  ej('Indica en qué año se comenzaron a construir estos monumentos de la ciudad de Toledo.',
     corta('Catedral Primada: MCCXXVI'),
     corta('Sinagoga del Tránsito: MCCCLV'),
     corta('Mezquita del Cristo de la Luz: CMXCIX')),
  ej('Lee y escribe la posición de cada persona con un número ordinal.',
     completar('Laura 7.º → ___\nYago 21.º → ___\nEmma 15.º → ___\nMia 26.º → ___\nPedro 30.º → ___\nLuisa 9.º → ___\nOmar 27.º → ___\nBlanca 18.º → ___',
               'Escribe con letras cada posición.'),
     problema('Alba está 11 lugares por detrás de Miguel, que está el tercero. ¿En qué posición está Alba?'),
     problema('Félix es el último. ¿Cuántos lugares por delante de él está Alba?'),
     ctx=texto('Para entrar al museo del Greco hay una cola formada por 30 personas.')),
])

empezar('t01-A')
examen('t01-A', 'Prueba de evaluación 1 · Modelo A', 'tema', [8, 9], tema=1, modelo='A', contexto=CTX, ejercicios=[
  ej('Averigua el año al que corresponde cada descomposición o lectura y completa.',
     completar('3 DM + 4 UM + 1 D + 6 U = ___ = ___\nSe lee ___\nAño ___'),
     completar('___ = ___\nSe lee «novecientos ochenta y tres».\nAño ___'),
     completar('___ = 40.000 + 8.000 + 500 + 70 + 3 = ___\nSe lee ___\nAño ___'),
     completar('___ = ___\nSe lee ___\nAño ___')),
  ej('Lee y contesta.',
     lineas('¿Qué año fueron menos personas? ¿Y más?', 2),
     problema('En mayo de 2018 visitaron Toledo menos personas que en 2019, pero más que en 2022. ¿Cuántas personas pudieron ser?'),
     lineas('Ordena los años de menor a mayor número de visitas recibidas, desde 2018 hasta 2022.', 2)),
  ej('Aproxima al orden que creas más adecuado el número de personas que visitaron Toledo cada año en mayo. Después, contesta.',
     completar('2019 → ___\n2020 → ___\n2021 → ___\n2022 → ___'),
     lineas('En el mes de mayo de 2023 se esperan aproximadamente 80.000 visitantes. ¿Cuántas personas podrían ir? '
            'Escribe un número menor y otro mayor que la aproximación.', 2)),
  ej('Observa el año de inicio y de finalización de la construcción de cada edificio y averigua cuántos años tardaron en construir cada uno.',
     problema('Catedral Primada: MCCXXVI a MCDXCIII'),
     problema('Sinagoga del Tránsito: CMXCIX a M')),
  ej('Lee y contesta utilizando números ordinales.',
     rellenar('¿Qué posición ocupa la persona que está en el último lugar en cada cola? Escríbelo con un ordinal y con letras.',
              ['Museo de Santa Cruz', 'Museo del Greco'], ['', '']),
     problema('Paola está en el lugar decimosexto para entrar al museo del Greco y Juan está diecisiete lugares por detrás de ella. '
              '¿Cuántas personas tiene ahora la cola?'),
     problema('Iván estaba en el lugar trigésimo cuarto para entrar al museo de Santa Cruz. Si entraron 9 personas, ¿en qué posición está ahora?'),
     ctx=texto('En la cola para entrar al museo de Santa Cruz hay 35 personas, y en la cola para visitar el museo del Greco hay 27.')),
])
