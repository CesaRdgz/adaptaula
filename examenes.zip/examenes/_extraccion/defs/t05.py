from ext import *

CTX = [titulo('¡Nos vamos de acampada!'),
       tabla(['Tipo de tienda', 'Capacidad (n.º de personas)', 'Precio por persona y noche'],
             ['Grande', '8', '4 €'], ['Mediana', '5', '7 €'], ['Pequeña', '2', '9 €'])]

def division(p):
    y0, y1 = {22: (0.452, 0.555), 24: (0.457, 0.57)}[p]
    return img(p, (0.22, y0, 0.79, y1), 'División 5.814 entre 8: cociente 726 y resto 6, con cuatro recuadros vacíos señalando dividendo, divisor, cociente y resto.')

def tabla3(total_g, total_m, completas_p):
    return rellenar('', ['Tipo de tienda', 'Grande', 'Mediana', 'Pequeña'],
                    ['N.º total de personas', total_g, total_m, ''],
                    ['N.º de personas por tienda', '', '', ''],
                    ['N.º de tiendas completas', '', '', completas_p],
                    ['N.º de personas en la tienda incompleta', '', '', '1'])

PREG3 = lambda: lineas('De las divisiones que has tenido que hacer, ¿cuál es entera y cuál es exacta? ¿Qué otras operaciones has utilizado?', 3)

empezar('t05-B')
examen('t05-B', 'Prueba de evaluación 5 · Modelo B', 'tema', [22, 23], tema=5, modelo='B', contexto=CTX, ejercicios=[
  ej('Escribe el nombre de los términos de esta división y comprueba que está resuelta correctamente. Después, completa.',
     dibujo('Escribe en cada recuadro el nombre del término.', ctx=division(22)),
     completar('Durante el mes de julio, se alojaron ___ personas en tiendas ___.\nSe llenaron ___ tiendas y ___ tienda quedó incompleta. '
               'En esta tienda durmieron ___ personas. En total, se ocuparon ___ tiendas.')),
  ej('Lee y resuelve con divisiones. Después, haz la prueba de cada una de ellas para comprobar tus respuestas.',
     problema('¿Cuántas veces se han usado como mínimo las tiendas medianas?'),
     problema('¿Y las tiendas pequeñas?'),
     ctx=texto('A lo largo de todo el año se han alojado 18.052 personas en las tiendas medianas y 20.136 en las pequeñas.')),
  ej('Observa los datos de hoy y completa la tabla. Después, contesta.', tabla3('304', '182', '67'), PREG3()),
  ej('Lee, busca los datos necesarios y resuelve los siguientes problemas.',
     problema('¿Cuánto dinero han recaudado en el camping esta semana?'),
     problema('Cada día de la semana hubo el mismo número de personas alojadas en el camping. ¿Cuántas personas se alojaron cada día?'),
     problema('La semana que viene se espera que se alojen 56 personas menos en tiendas grandes y 39 menos en medianas. ¿Cuántas personas se alojarán?'),
     ctx=texto('Esta semana se han alojado en el camping 608 personas en tiendas grandes, 526 en tiendas medianas y ninguna en tiendas pequeñas.')),
])

empezar('t05-A')
examen('t05-A', 'Prueba de evaluación 5 · Modelo A', 'tema', [24, 25], tema=5, modelo='A', contexto=CTX, ejercicios=[
  ej('Escribe el nombre de los términos de esta división y comprueba que está resuelta correctamente. Después, completa.',
     dibujo('Escribe en cada recuadro el nombre del término.', ctx=division(24)),
     lineas('Inventa una situación donde expliques qué representa cada término de la división.', 4)),
  ej('Lee y resuelve con divisiones. Después, haz la prueba de cada una de ellas para comprobar tus respuestas.',
     problema('¿Cuántas veces se han usado como mínimo las tiendas medianas?'),
     problema('¿Y las tiendas pequeñas?'),
     ctx=texto('A lo largo de todo el año se han alojado 18.350 personas en las tiendas medianas y 24.109 en las pequeñas.')),
  ej('Observa los datos de esta semana y completa la tabla. Después, contesta.', tabla3('2.128', '2.274', '472'), PREG3()),
  ej('Lee, busca los datos necesarios y resuelve los siguientes problemas.',
     problema('¿Cuántas personas se han alojado en las tiendas pequeñas? ¿Se han completado todas las tiendas?'),
     problema('¿Cuánto dinero han recaudado en el camping esta semana?'),
     problema('La semana que viene esperan alojar a la mitad de personas en tiendas grandes, el triple en tiendas medianas y 100 personas más '
              'en tiendas pequeñas. ¿Cuántas personas alojarán en total esa semana?'),
     ctx=texto('Esta semana se han alojado en el camping 608 personas en tiendas grandes y 526 en tiendas medianas. En total se han alojado 1.267 personas.')),
])
