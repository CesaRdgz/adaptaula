from ext import *

CTX = [titulo('En el supermercado'),
       texto('Algunos productos del supermercado:'),
       lista('Yogures: paquetes de 8 yogures.', 'Leche: paquetes de 6 briks.', 'Queso: sobres de 10 lonchas.',
             'Papel higiénico: paquetes de 24 rollos.', 'Aceitunas: botes de 82 unidades.', 'Servilletas: paquetes de 200 unidades.')]

EJ1 = lambda: ej('Realiza las siguientes multiplicaciones e indica qué se calcula en cada caso.',
     *[calculo(o) for o in ['125 × 8', '247 × 6', '1.305 × 10', '1.012 × 24', '354 × 82', '109 × 200']])

PROB_LECHE = 'Al supermercado ha llegado un camión de reparto con 96 paquetes de leche. Si ya había 17 paquetes, ¿cuántos briks de leche hay ahora para vender?'

empezar('t03-B')
examen('t03-B', 'Prueba de evaluación 3 · Modelo B', 'tema', [14, 15], tema=3, modelo='B', contexto=CTX, ejercicios=[
  EJ1(),
  ej('Piensa y resuelve estimando.',
     problema('¿Cuántos yogures se venderán en una semana si cada día se venden 96 paquetes?'),
     problema('¿Cuántas aceitunas se comprarán en 9 días si cada día se compran 7 botes?')),
  ej('Explica qué se puede hallar con cada operación. Después, aplica la propiedad indicada y calcula, comprobando que obtienes el mismo resultado.',
     calculo('Conmutativa: 16 × 6'),
     calculo('Conmutativa: 25 × 200'),
     calculo('Asociativa: (3 × 10) × 2'),
     calculo('Asociativa: 24 × (3 × 6)'),
     calculo('Distributiva: 2 × (8 + 5)'),
     calculo('Distributiva: (82 − 15) × 3')),
  ej('Resuelve utilizando operaciones combinadas.',
     problema(PROB_LECHE),
     problema('Diego ha comprado 3 paquetes de yogures. ¿Cuántos yogures tiene ahora en total si en casa le quedaban 5 yogures de fresa y 2 de limón?'),
     problema('Marieta tenía en casa un paquete de papel higiénico, del que ha gastado 8 rollos. '
              '¿Cuántos rollos tiene en casa ahora si ha comprado 2 paquetes más en el supermercado?')),
])

empezar('t03-A')
examen('t03-A', 'Prueba de evaluación 3 · Modelo A', 'tema', [16, 17], tema=3, modelo='A', contexto=CTX, ejercicios=[
  EJ1(),
  ej('Completa la tabla y estima el total de briks de leche que han llegado hoy al supermercado.',
     rellenar('', ['', 'Entera', 'Semidesnatada', 'Desnatada', 'Total'],
              ['N.º de paquetes', '385', '107', '92', '—'],
              ['N.º de briks', '', '', '', ''])),
  ej('Piensa y estima cuántos paquetes de cada tipo pueden tener en el supermercado para que en total tengan unos 1.200 briks de leche y unos 480 yogures.',
     problema('')),
  ej('Resuelve con una operación combinada cada situación. Después, utiliza las propiedades de la multiplicación y reescríbelas de otra forma, comprobando tus resultados.',
     calculo('El total de servilletas que hay en 25 paquetes.'),
     calculo('El total de rollos de papel higiénico en una estantería en la que hay 6 filas de 3 paquetes cada una.'),
     calculo('El total de aceitunas que quedan en 3 botes si de cada uno se han comido 15 aceitunas.')),
  ej('Resuelve utilizando operaciones combinadas.',
     problema(PROB_LECHE),
     problema('Marieta tenía en casa dos paquetes de papel higiénico. Ha llevado 15 rollos a su autocaravana y, de los que quedaban en casa, '
              'ha gastado 14 más. ¿Cuántos rollos tiene en casa ahora?'),
     problema('En casa de Alberto quedaban 3 yogures. Han comprado 2 paquetes de yogures naturales y un paquete de yogures de fresa. '
              'Ya se han tomado 5 yogures naturales y 4 de fresa. ¿Cuántos yogures quedan?')),
])
