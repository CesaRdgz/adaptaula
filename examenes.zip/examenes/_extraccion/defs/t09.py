from ext import *

CTX = [titulo('Envíos internacionales'),
       texto('Precio del envío de paquetes según la zona y su peso:'),
       tabla(['', 'Zona 1', 'Zona 2', 'Zona 3'],
             ['Hasta 2 kg', '42,05 €', '46,95 €', '70,35 €'],
             ['Hasta 5 kg', '45,50 €', '51,35 €', '82,60 €'],
             ['Cada kg extra', '3,35 €', '4,40 €', '12,25 €'])]

def cuadriculas():
    return cuadriculas_decimal('Dos cuadrículas de 10 × 10 para colorear: «4 décimas» con «4 d = —— =» y «65 centésimas» con «65 c = —— =».')

def ej1(*preguntas):
    return ej('Colorea las cuadrículas para representar el peso de cada paquete. Después, escribe en forma de fracción y de número decimal y contesta.',
              dibujo('', ctx=cuadriculas()),
              completar('4 d = ___ = ___\n65 c = ___ = ___'),
              *preguntas)

def ej2(peso_z3):
    return ej('Escribe el precio del envío de cada paquete. Después, escribe la descomposición y la lectura de cada precio.',
              completar('Precio: ___\nDescomposición: ___\nLectura: ___', 'Zona 1, paquete de 1,76 kg.'),
              completar('Precio: ___\nDescomposición: ___\nLectura: ___', f'Zona 3, paquete de {peso_z3} kg.'))

PRECIOS = completar('5 D + 1 U + 3 d + 5 c = ___\n4 D + 6 U + 9 d + 5 c = ___\nSetenta coma treinta y cinco → ___\nCuarenta y cinco coma cincuenta → ___',
                    'Escribe el precio.')
ITEMS = ['5 D + 1 U + 3 d + 5 c', '4 D + 6 U + 9 d + 5 c', 'Setenta coma treinta y cinco', 'Cuarenta y cinco coma cincuenta']
PESOS = ['1,24 kg', '1,96 kg', '4,5 kg', '3,62 kg']
ORDENA = lambda: lineas('Ordena de menor a mayor los precios de estos envíos: 48,85 € · 52,20 € · 51,35 € · 94,85 € · 55,75 € · 60,15 €', 2)

empezar('t09-B')
examen('t09-B', 'Prueba de evaluación 9 · Modelo B', 'tema', [38, 39], tema=9, modelo='B', contexto=CTX, ejercicios=[
  ej1(problema('¿Cuántas décimas pesa un paquete de 0,5 kg?'),
      problema('¿Cuántas centésimas pesa un paquete de 0,80 kg? ¿Y décimas?'),
      problema('¿Cuántas décimas y centésimas pesa un paquete de 0,75 kg?')),
  ej2('4,2'),
  ej('Escribe el precio de los envíos que corresponden a estas descomposiciones y lecturas. Después, une con su zona de envío y con su peso.',
     PRECIOS,
     unir('Une cada precio con su zona de envío.', ITEMS, ['Zona 3', 'Zona 2', 'Zona 1', 'Zona 2']),
     unir('Une cada precio con su peso.', ITEMS, PESOS)),
  ej('Lee y contesta.',
     lineas('¿Qué paquete pesa más: uno de 3,6 kg u otro de 3,78 kg?', 1),
     problema('¿A qué zona es más barato enviar un paquete de 4,07 kg?'),
     ORDENA()),
  ej('Resuelve cada problema con sumas o restas.',
     problema('Julia va a enviar un paquete de 5,86 kg a la zona 2. ¿Cuánto pagará?'),
     problema('Valentín va a enviar dos paquetes a la zona 1. El primero pesa 5,2 kg, y el segundo, 1,07 kg. ¿Cuánto pagará en total?'),
     problema('Claudia va a enviar un paquete de 1,28 kg a la zona 3, y Jero, uno de 4,73 kg a la zona 1. ¿Qué paquete pesa más? ¿Cuánto más?'),
     problema('¿Quién pagará más, Claudia o Jero? ¿Cuántos euros más?')),
])

empezar('t09-A')
examen('t09-A', 'Prueba de evaluación 9 · Modelo A', 'tema', [40, 41], tema=9, modelo='A', contexto=CTX, ejercicios=[
  ej1(problema('¿Cuántas centésimas pesa un paquete de 0,80 kg? ¿Y décimas?'),
      problema('¿Cuántas décimas y centésimas pesa un paquete de 0,39 kg?'),
      problema('Un paquete pesa 700 centésimas de kilo. ¿Cuántos kilos son?')),
  ej2('4,03'),
  ej('Escribe el precio de los envíos que corresponden a estas descomposiciones y lecturas. Después, une con su peso.',
     PRECIOS,
     unir('Une cada precio con su peso.', ITEMS, PESOS)),
  ej('Lee y contesta.',
     problema('¿A qué zona es más barato enviar un paquete de 4,07 kg?'),
     lineas('Un paquete tiene un peso que está entre 4,9 kg y 5,12 kg. Indica tres pesos posibles y el precio de su envío a la zona 2 en cada caso.', 3),
     ORDENA()),
  ej('Resuelve cada problema con sumas o restas.',
     problema('¿Qué paquete pesa más? ¿Cuánto más?'),
     problema('¿Cuánto pagarán entre los dos?'),
     problema('¿Quién pagará más? ¿Cuántos euros más?'),
     problema('Valentín va a enviar dos paquetes de 5,6 kg cada uno: uno a la zona 2 y otro a la zona 3. ¿En qué envío pagará más? ¿Cuánto más?'),
     ctx=texto('Claudia va a enviar un paquete de 1,28 kg a la zona 3, y Jero, uno de 4,7 kg a la zona 1.')),
])
