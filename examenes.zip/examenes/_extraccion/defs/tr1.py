from ext import *

CTX = [titulo('Dentro de la juguetería'),
       texto('El concurso del año. Premios del concurso:'),
       lista('Caja con vías del tren: 36 €', 'Bote de bloques de construcción: 45 €', 'Arcoíris de madera: 59 €', 'Cestos de frutas: 12 €')]

# El texto de la nota es WordArt en el Word y no sale al convertir la página; se ha sacado del XML.
NOTA = texto('En el mes de enero, por las ventas, obtuvieron 26.784 €, en febrero 9.524 € y en marzo 15.368 €.')

def ej1(cantidades, comparacion):
    return ej('Completa la tabla con el dinero que ganarían en la juguetería si vendieran todos los juguetes de cada tipo que tienen. '
              'Después, contesta, calculando de forma exacta y aproximada.',
              rellenar('', ['Tipo de caja', 'N.º de cajas', '€/caja', 'Total'],
                       ['Vías del tren', '', '', ''], ['Bloques de construcción', '', '', ''],
                       ['Arcoíris de madera', '', '', ''], ['Cestos de frutas', '', '', '']),
              problema('¿Cuánto dinero obtendrían por la venta de los arcoíris y los bloques de construcción?'),
              problema(f'¿Cuántos euros más ganarían por las vías del tren que por {comparacion}?'),
              problema('¿Cuánto dinero obtendrían en total?'),
              ctx=texto(f'En la juguetería tienen {cantidades}.'))

def ej2(aproxima, ultima):
    return ej('Escribe la descomposición y la lectura de los números del texto.',
              lineas('Descomposición y lectura de cada número.', 6),
              lineas('Ordénalos de mayor a menor.', 1),
              lineas(aproxima, 2),
              ultima,
              ctx=NOTA)

def geoplano(p, caja):
    return ej('En la juguetería también venden geoplanos de madera. Observa las figuras formadas e indica para cada una de ellas su perímetro y su área.',
              calculo('', ctx=[img(p, caja, 'Figuras formadas en un geoplano sobre una trama de puntos.', medir=False),
                               texto('La distancia entre dos clavos seguidos es de 20 mm, y la diagonal de un cuadrado de la trama mide 28 mm.')]))

empezar('tr1-B')
examen('tr1-B', 'Evaluación del primer trimestre · Modelo B', 'trimestre', [54, 55], trimestre=1, modelo='B', contexto=CTX, ejercicios=[
  ej1('48 cajas de vías del tren, 89 botes de bloques de construcción, 18 arcoíris de madera y 26 cestos de frutas', 'los arcoíris'),
  ej2('Aproxima cada número a los millares.',
      problema('El dinero que obtuvieron en abril fue mayor que en febrero, pero menor que en marzo. ¿Cuánto dinero puede ser?')),
  ej('Lee y resuelve con operaciones combinadas.',
     problema('En la caja de vías de tren, hay 22 piezas curvas y 14 piezas rectas. ¿Cuántas piezas hay en total en 2 cajas?'),
     problema('En el bote de bloques de construcción hay 34 piezas azules, el doble de verdes que de azules y 78 amarillas. ¿Cuántas piezas hay en el bote en total?')),
  geoplano(56, (0.10, 0.75, 0.62, 0.935)),
])

empezar('tr1-A')
examen('tr1-A', 'Evaluación del primer trimestre · Modelo A', 'trimestre', [56, 57], trimestre=1, modelo='A', contexto=CTX, ejercicios=[
  ej1('120 cajas de vías del tren, 254 botes de bloques de construcción, 65 arcoíris de madera y 94 cestos de frutas', 'los cestos de frutas'),
  ej2('Aproxima cada número a los millares y a las centenas.',
      lineas('Escribe cuántos euros pudieron ganar en abril y mayo sabiendo que obtuvieron más o menos 19.000 € y 12.500 €, respectivamente.', 2)),
  ej('Lee y resuelve con operaciones combinadas.',
     problema('En la caja de vías de tren, hay 47 piezas curvas, 23 piezas rectas y 4 puentes. ¿Cuántas piezas hay en total en 3 cajas?'),
     problema('En el bote de bloques de construcción hay 28 piezas azules, el triple de verdes que de azules y 5 piezas menos rojas que azules. ¿Cuántas hay en total en el bote?')),
  geoplano(58, (0.12, 0.75, 0.65, 0.95)),
])
