from ext import *

CTX = [titulo('De visita en el Museo Geominero'),
       texto('Número de elementos en el museo, por tipo:'),
       lista('Gemas: 159', 'Rocas: 217', 'Fósiles invertebrados: 45.125', 'Fósiles vertebrados: 6.090')]

ROCAS = 'Hoy llegan 29 rocas nuevas al museo. Para almacenarlas todas, pondrán 24 rocas en cada una de las 9 vitrinas que tienen. ¿Cuántas rocas quedarán sin almacenar?'

def gemas(p, caja):
    return ej('Observa las siguientes gemas talladas y clasifícalas según el tipo de cuerpo que son.',
              lineas('Escribe debajo de cada gema el tipo de cuerpo geométrico.', 2,
                     ctx=img(p, caja, 'Fotografías de cinco gemas talladas con formas distintas.')))

def ej3(datos, segunda):
    return ej('Observa los datos y calcula.',
              lineas('¿Qué fracción de los meteoritos son grandes? ¿Y pequeños?', 2),
              lineas(segunda, 2),
              lineas('Ordena todas las fracciones anteriores de menor a mayor.', 2),
              ctx=[texto('Colección de meteoritos:'), lista(*datos)])

empezar('tr2-B')
examen('tr2-B', 'Evaluación del segundo trimestre · Modelo B', 'trimestre', [58, 59], trimestre=2, modelo='B', contexto=CTX, ejercicios=[
  ej('Observa los datos, lee y contesta.',
     problema('Las gemas están expuestas en 6 vitrinas. Todas las vitrinas tienen el mismo número de gemas. ¿Faltan gemas por exponer?'),
     problema('Los fósiles invertebrados están repartidos en 94 expositores y los vertebrados en 50. ¿Cuántos fósiles hay en cada tipo de expositor? ¿Cuántos quedan sin exponer?')),
  ej('Resuelve con una operación combinada.',
     problema('La próxima semana llegarán al museo 13 gemas y se retirarán 16. Si se exponen en 6 vitrinas, ¿cuántas gemas habrá en cada vitrina?'),
     problema(ROCAS)),
  ej3(['15 piezas en total', 'Grandes: 6 piezas', 'Pequeños: 9 piezas'],
      'La fracción de meteoritos que hay expuestos es mayor que la fracción de meteoritos grandes y menor que la fracción de meteoritos pequeños. ¿Qué fracción puede ser?'),
  ej('Lee y resuelve.',
     problema('De todos los fósiles invertebrados del museo, solo van a exponer tres quintas partes. ¿Cuántos expondrán?'),
     problema('Del total de gemas, 2/3 miden menos de 2 cm, y del total de rocas, 2/7. ¿Cuántas gemas y rocas en total miden menos de 2 cm?')),
  gemas(60, (0.13, 0.755, 0.935, 0.875)),
])

empezar('tr2-A')
examen('tr2-A', 'Evaluación del segundo trimestre · Modelo A', 'trimestre', [60, 61], trimestre=2, modelo='A', contexto=CTX, ejercicios=[
  ej('Observa los datos, lee y contesta.',
     problema('Las gemas están expuestas en 7 vitrinas. Todas tienen el mayor número de gemas posible, excepto una de ellas. ¿Cuántas gemas hay en cada vitrina?'),
     problema('Los fósiles invertebrados están repartidos en 94 expositores y los vertebrados en 50. ¿Cuántos fósiles quedan sin exponer en total?')),
  ej('Resuelve con una operación combinada.',
     problema('La próxima semana llegarán al museo 13 gemas y se retirarán 16, y llegarán 21 rocas y se retirarán 34. Si se exponen en 8 vitrinas, todas mezcladas, '
              '¿cuántos elementos habrá en cada vitrina?'),
     problema(ROCAS)),
  ej3(['Grandes: 4 piezas', 'Pequeños: 31 piezas'],
      'La fracción de meteoritos que hay expuestos es mayor que la fracción de meteoritos pequeños y menor que la unidad. ¿Qué fracción puede ser?'),
  ej('Lee y resuelve.',
     problema('De todos los fósiles del museo, han decidido que van a exponer solo tres quintas partes de los invertebrados y cinco sextas partes de los vertebrados. '
              '¿Cuántos fósiles expondrán en total?'),
     problema('Del total de gemas, 2/3 miden menos de 2 cm, y del total de rocas, 2/7. ¿Cuántas gemas y rocas en total miden más de 2 cm?')),
  gemas(62, (0.13, 0.77, 0.935, 0.89)),
])
