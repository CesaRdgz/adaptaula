from ext import *

CTX = [titulo('Recolectando bayas'),
       texto('Número de bayas totales y por caja recogidas hoy en el huerto:'),
       tabla(['Baya', 'Total', 'Por caja'],
             ['Fresas', '9.346', '45'], ['Arándanos', '25.506', '98'], ['Frambuesas', '12.859', '72'], ['Moras', '38.672', '81'])]

def cajas(ultima):
    return ej('Observa los datos y calcula cuántas cajas de cada tipo de baya se han obtenido hoy. Después, contesta.',
              calculo('Fresas:'), calculo('Arándanos:'), calculo('Frambuesas:'), calculo('Moras:'), ultima)

EJ2 = lambda: ej('Lee y contesta utilizando las propiedades de la división.',
     problema('¿Obtuvieron el doble de cajas de fresas si las envasaron en cajas con el doble de fresas? ¿Cuántas fresas sobraron?'),
     problema('¿Obtuvieron la mitad de cajas de arándanos si las envasaron en cajas con la mitad de arándanos? ¿Cuántos sobraron?'),
     ctx=texto('Hace unos días recolectaron el doble de fresas y la mitad de arándanos.'))

empezar('t06-B')
examen('t06-B', 'Prueba de evaluación 6 · Modelo B', 'tema', [26, 27], tema=6, modelo='B', contexto=CTX, ejercicios=[
  cajas(lineas('¿Cuántas frutas de cada tipo han quedado sin envasar al no poder completar una caja?', 3)),
  EJ2(),
  ej('Lee y resuelve.',
     problema('Esta mañana, por la venta de 200 cajas de frambuesas, han obtenido 2.400 €. ¿Cuál es el precio de una caja de frambuesas?')),
  ej('Une cada operación combinada con su expresión correspondiente.',
     unir('', ['(8 + 9) × 5', '(9 + 6) : 5', '8 × 5 + 9 × 6'],
          ['El precio de 8 cajas de fresas y 9 cajas de arándanos si la caja de fresas cuesta 5 € y la de arándanos 6 €.',
           'El número de cajas que ha comprado Marta este mes si fue a la compra 5 veces y cada vez compró 8 cajas de fresas y 9 cajas de moras.',
           'El número de fresas que ha puesto Iván en cada uno de los 5 platos si tenía 9 fresas en una caja y 6 en otra.'])),
  ej('Lee y resuelve los siguientes problemas con operaciones combinadas.',
     problema('Esteban ha hecho un pedido al huerto para que le preparen 6 cajas de fresas y 12 cajas de arándanos, pero finalmente '
              'le han servido dos cajas menos de arándanos porque no tenían más. Si cada caja de fresas cuesta 5 € y cada caja de arándanos 6 €, '
              '¿cuánto ha pagado Esteban por el pedido final?'),
     problema('Maya ha preparado 7 tartas de frambuesas. En total ha utilizado 350 frambuesas para el relleno y 112 para decorar. '
              '¿Cuántas frambuesas ha utilizado en cada tarta?')),
])

empezar('t06-A')
examen('t06-A', 'Prueba de evaluación 6 · Modelo A', 'tema', [28, 29], tema=6, modelo='A', contexto=CTX, ejercicios=[
  cajas(problema('Se ha repartido el total de bayas que han sobrado en bolsitas de frutas variadas. '
                 'Si en cada una han metido 15 frutas, ¿cuántas bolsas han obtenido?')),
  EJ2(),
  ej('Lee y resuelve.',
     problema('Esta mañana, por la venta de 970 cajas de frambuesas, han obtenido 10.670 €. ¿Cuál es el precio de una caja de frambuesas?')),
  ej('Piensa si las siguientes afirmaciones son verdaderas o falsas y justifica tu respuesta.',
     lineas('Con la expresión 81 × 2 − 45 × 3 se calcula el número de fresas que hay en 3 cajas más que en 2 cajas de moras.', 3),
     lineas('Con la expresión (72 − 7) : 5 se calcula el número de frambuesas que hay en cada uno de los 5 cuencos de una mesa, '
            'si se han quitado 7 frambuesas de la caja.', 3)),
  ej('Lee, busca los datos necesarios y resuelve los siguientes problemas con operaciones combinadas.',
     problema('Esteban ha hecho un pedido al huerto para que le preparen 8 cajas de fresas y 12 cajas de arándanos, pero le han llegado '
              'la mitad de las cajas de arándanos que necesitaba. Si cada caja de fresas cuesta 5 € y cada caja de arándanos 6 €, '
              '¿cuánto ha pagado Esteban por el pedido que ha recibido?'),
     problema('Maya ha preparado 7 tartas de frambuesas. En cada tarta ha utilizado 50 frambuesas para el relleno y 16 para decorar. '
              '¿Cuántas cajas de frambuesas ha necesitado?')),
])
