from ext import *

CTX = [titulo('Con las manos en la masa'),
       texto('Ingredientes de la masa base para un pan:'),
       lista('Harina de trigo: 500 g', 'Agua: 350 g', 'Levadura fresca: 1 g', 'Sal: 10 g')]

EJ1 = lambda: ej('Aplica la propiedad indicada en cada caso y comprueba los resultados.',
     calculo('Propiedad conmutativa: 500 + 350'),
     calculo('Propiedad conmutativa: 500 + 10'),
     calculo('Propiedad asociativa: 500 + (1 + 10)'),
     calculo('Propiedad asociativa: (350 + 500) + 1'),
     lineas('Indica, en cada operación, qué ingredientes se han mezclado y en qué orden, en cada lado de la igualdad.', 3))

empezar('t02-B')
examen('t02-B', 'Prueba de evaluación 2 · Modelo B', 'tema', [10, 11], tema=2, modelo='B', contexto=CTX, ejercicios=[
  EJ1(),
  ej('Completa los huecos en cada caso y comprueba los resultados. Después, indica a qué otros ingredientes pueden corresponder '
     'los números que no aparecen entre los de la masa base.',
     completar('500 + ___ = 25 + ___'),
     completar('500 + (___ + 10) = (___ + 120) + ___'),
     completar('___ + 350 = ___ + 87'),
     completar('(350 + ___) + 2 = ___ + (1 + ___)'),
     lineas('¿A qué otros ingredientes pueden corresponder los números que no aparecen entre los de la masa base?', 2)),
  ej('Resuelve con operaciones combinadas de sumas y restas.',
     problema('¿Cuánto pesará un pan entero hecho solo con la masa base?'),
     problema('¿Cuánto más pesarán dos panes de masa base que otro hecho con harina de centeno que pesa 950 g?'),
     problema('Tengo tres paquetes de harina abiertos: uno con 155 g, otro con 198 g y el último con 61 g. '
              '¿Cuánta harina me falta para poder hacer un pan?'),
     problema('De un paquete de 1 kg de harina gasté 50 g para rebozar albóndigas y 80 g para hacer bechamel. '
              '¿Cuánta harina quedará si hago un pan de masa base?')),
  ej('Calcula el peso total de cada pan realizando estimaciones. Después, contesta.',
     calculo('Pan de leche: masa base, leche (315 g) y mantequilla (100 g).'),
     calculo('Pan de higos: masa base, aceite de oliva (15 g) e higos (125 g).'),
     problema('¿Cuánto pesa una hogaza integral de 768 g menos que un pan de leche, aproximadamente? '
              '¿Y un pan payés de 1.200 g más que un pan de higos?')),
])

empezar('t02-A')
examen('t02-A', 'Prueba de evaluación 2 · Modelo A', 'tema', [12, 13], tema=2, modelo='A', contexto=CTX, ejercicios=[
  EJ1(),
  ej('Observa el peso de estos ingredientes para añadir a la masa base y escribe con una suma cada combinación. '
     'Después, calcula y reescríbelas utilizando propiedades de la suma.',
     calculo('Primero harina y, después, azúcar.'),
     calculo('Primero azúcar y, después, harina.'),
     calculo('Primero agua y, después, aceite con sal.'),
     calculo('Primero agua con aceite y, después, sal.'),
     ctx=lista('Azúcar: 62 g', 'Aceite de oliva: 18 g')),
  ej('Resuelve con operaciones combinadas de sumas y restas.',
     problema('¿Cuánto pesará un pan entero hecho solo con la masa base?'),
     problema('Tengo tres paquetes de harina abiertos: uno con 545 g, otro con 239 g y el último con 78 g. '
              '¿Cuánta harina me falta para poder hacer dos panes?'),
     problema('De un paquete de 5 kg de harina gasté 1.257 g para hacer varios bizcochos, 245 g para hacer tortitas '
              'y 80 g para hacer bechamel. Después, haré un pan. ¿Cuánta harina quedará en el paquete?')),
  ej('Inventa un problema para cada operación combinada. Después, resuélvelos.',
     lineas('(350 + 15) + (500 + 10 + 1)', 5),
     lineas('1.258 − (861 + 300)', 5)),
  ej('Piensa y contesta realizando estimaciones.',
     problema('¿Cuánto pesa aproximadamente una hogaza de harina integral de 1.168 g más que un pan de leche de 752 g?'),
     problema('¿Cuántos gramos pesa un pan payés si su peso es aproximadamente como el de dos barras de 285 g menos el de un mollete de 128 g?')),
])
