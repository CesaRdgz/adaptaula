from ext import *

CTX = [titulo('Figuritas de papel'),
       texto('Cantidad de papel que se usa para hacer cada figura:'),
       lista('Grulla: un cuarto de folio', 'Tulipán: dos tercios de folio', 'Barco: medio folio', 'Estrella: cinco sextos de folio')]

def ej1(p, y0, y1):
    return ej('Observa los datos y escribe la fracción de papel que se utiliza para realizar cada figurita. Después, completa con el nombre de los términos y representa cada fracción.',
              dibujo('Grulla: 1/4. Escribe el nombre de cada término y represéntala en la cuadrícula.'),
              dibujo('Tulipán: escribe la fracción y represéntala.'),
              dibujo('Barco: escribe la fracción y represéntala.'),
              dibujo('Estrella: escribe la fracción y represéntala.'),
              ctx=img(p, (0.12, y0, 0.82, y1), 'Fracción 1/4 de la grulla con dos recuadros para los nombres de los términos, y cuatro cuadrículas para representar las fracciones de la grulla, el tulipán, el barco y la estrella.'))

def folios(p, y0, y1):
    return img(p, (0.12, y0, 0.58, y1), 'Montón de folios de tres tipos: con cruces, con lunares y con barras.')

def ej3(ultima):
    return ej('Observa los datos anteriores y responde.',
              lineas('¿Se necesita más de un folio para construir cada figura?', 2),
              lineas('¿Para qué figura se necesita más papel: para una grulla o un barco? ¿Por qué?', 2),
              ultima)

empezar('t07-B')
examen('t07-B', 'Prueba de evaluación 7 · Modelo B', 'tema', [30, 31], tema=7, modelo='B', contexto=CTX, ejercicios=[
  ej1(30, 0.44, 0.70),
  ej('Fíjate en el número de folios de cada tipo y escribe la fracción del conjunto que representan.',
     corta('Cruces:'), corta('Lunares:'), corta('Barras:'), ctx=folios(30, 0.76, 0.90)),
  ej3(lineas('Para hacer un pez se utilizan 4/6 de un folio. ¿Es menos papel que para hacer un pez o una estrella?', 2)),
  ej('Ordena las fracciones de folio que se usan para construir estas figuras y rodea las que son mayores que la unidad.',
     lineas('', 2, ctx=lista('Ratón: 2/7', 'Abanico: 5/3', 'Gato: 5/7', 'Dragón: 3/7', 'Medusa: 5/6'))),
  ej('Lee y resuelve.',
     problema('¿Cuántos folios tiene de cada color?'),
     problema('Utilizará 2/25 de los folios rojos para hacer un barco con cada folio y 7/40 de los folios verdes para una estrella con cada folio. '
              '¿Cuántos barcos construirá? ¿Y estrellas?'),
     ctx=texto('Manuel tiene un paquete de 500 folios de colores: 2/5 son verdes, 1/10 son rojos y 3/6 son azules.')),
])

empezar('t07-A')
examen('t07-A', 'Prueba de evaluación 7 · Modelo A', 'tema', [32, 33], tema=7, modelo='A', contexto=CTX, ejercicios=[
  ej1(32, 0.45, 0.71),
  ej('Fíjate en el número de folios de cada tipo que hay y escribe la fracción del conjunto que representan.',
     corta('Cruces:'), corta('Lunares:'), corta('Barras:'),
     lineas('Reescribe las fracciones si hubiera un folio más de barras.', 2),
     ctx=folios(32, 0.78, 0.92)),
  ej3(lineas('Para hacer un pez se utilizan 4/6 de un folio. ¿Se necesita menos papel para hacer un pez o una estrella?', 2)),
  ej('Piensa y contesta.',
     lineas('Para hacer un abanico de papel se utiliza una fracción de papel mayor que para una grulla, pero menor que la unidad. Indica tres fracciones posibles.', 2)),
  ej('Lee y resuelve.',
     problema('¿Cuántos folios tiene de cada color?'),
     problema('Usará 3/35 de los folios rojos para hacer barcos y 7/40 de los folios azules para hacer estrellas. ¿Cuántos rojos y azules no usará?'),
     ctx=texto('Manuel tiene un paquete de 500 folios de colores: 6/15 son verdes, 7/25 son rojos y 8/25 son azules.')),
])
