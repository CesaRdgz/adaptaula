from ext import *

def ctx(p):
    return [titulo('Iluminando nuestro hogar'),
            img(p, (0.10, 0.145, 0.90, 0.40), 'Fotografías de siete lámparas de formas distintas, marcadas con las letras A, B, C, D, E, F y G.')]

def desarrollos(p, y0, y1):
    return img(p, (0.12, y0, 0.92, y1), 'Cuatro desarrollos planos de lámparas de papel: una estrella de triángulos alrededor de un hexágono, '
               'un sector circular con un círculo, un pentágono rodeado de rectángulos con otro pentágono, y un rectángulo con dos círculos.')

empezar('t08-B')
examen('t08-B', 'Prueba de evaluación 8 · Modelo B', 'tema', [34, 35], tema=8, modelo='B', contexto=ctx(34), ejercicios=[
  ej('Observa las lámparas y escribe cuáles de ellas son poliedros. Después, indica las que son prismas o pirámides, clasifícalas y describe sus elementos '
     '(número de bases, vértices, caras laterales y aristas).', lineas('', 6)),
  ej('Fíjate en las lámparas anteriores y responde.',
     lineas('¿Cuáles de ellas están formadas por cuerpos redondos? ¿Qué cuerpos son? Clasifícalos.', 4),
     lineas('Indica si tienen vértices o no, su número de bases y sus superficies curvas.', 4)),
  ej('Completa los siguientes textos con las palabras de los recuadros.',
     completar('Los ___ son cuerpos geométricos que tienen todas sus superficies ___.'),
     completar('Los ___ son poliedros que tienen dos ___, que son polígonos ___ y paralelos, y varias caras laterales, que son ___.'),
     completar('Las ___ son poliedros que tienen una base, que es un ___, y varias caras laterales, que son ___ unidos en un punto en común.'),
     ctx=lista('triángulos', 'prismas', 'pirámides', 'iguales', 'poliedros', 'paralelogramos', 'planas', 'bases', 'polígono')),
  ej('Observa los siguientes desarrollos planos de estas lámparas construidas con papel e indica a qué tipo de cuerpo geométrico pertenecen. Clasifícalos y contesta.',
     lineas('Escribe debajo de cada desarrollo plano a qué cuerpo geométrico pertenece y clasifícalo.', 2, ctx=desarrollos(35, 0.53, 0.71)),
     lineas('Una lámpara con forma de esfera, ¿tiene desarrollo plano?', 2),
     dibujo('Dibuja una lámpara con forma de pirámide cuadrangular y su desarrollo plano, y marca sobre ella dos vértices en color rojo, la base en azul y dos aristas en verde.')),
])

empezar('t08-A')
examen('t08-A', 'Prueba de evaluación 8 · Modelo A', 'tema', [36, 37], tema=8, modelo='A', contexto=ctx(36), ejercicios=[
  ej('Observa las lámparas y escribe cuáles de ellas son poliedros. Después, indica las que son prismas o pirámides, clasifícalas y describe sus elementos.',
     lineas('', 6)),
  ej('Fíjate en las lámparas anteriores y responde.',
     lineas('¿Cuáles de ellas están formadas por cuerpos redondos? ¿Qué cuerpos son? Clasifícalos.', 4),
     lineas('Describe todas las características y los elementos de cada una de ellas.', 4)),
  ej('Completa los siguientes textos con las palabras de los recuadros.',
     completar('El número de aristas de un ___ es el ___ que el número de lados que tiene la ___.'),
     completar('El número de vértices de una ___ es igual al número de ___ de la base más ___.'),
     completar('Los ___ tienen dos ___, los conos solo tienen una y las ___ ninguna.'),
     ctx=lista('base', 'cilindros', 'prisma', 'pirámide', 'esferas', 'bases', 'uno', 'lados', 'triple')),
  ej('Observa los siguientes desarrollos planos de estas lámparas construidas con papel e indica a qué tipo de cuerpo geométrico pertenecen. Clasifícalos y contesta.',
     lineas('Escribe debajo de cada desarrollo plano a qué cuerpo geométrico pertenece y clasifícalo.', 2, ctx=desarrollos(37, 0.50, 0.68)),
     lineas('Una lámpara con forma de esfera, ¿tiene desarrollo plano?', 2),
     dibujo('Dibuja una lámpara con forma de prisma octogonal y su desarrollo plano, y marca sobre ella dos vértices en color rojo, '
            'una base en azul, dos aristas en verde y una cara lateral en amarillo.')),
])
