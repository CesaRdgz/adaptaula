# Catálogo: Evaluación 360º · Matemáticas 4.º Primaria

Exámenes del cuaderno de Santillana pasados al formato de Adaptaula (`src/lib/examen.ts`).
**Material con copyright: esta carpeta no se sube al repositorio** (está en `.gitignore`).

- `catalogo.json`: índice, en el orden del curso (inicial, temas 1-12 con modelo B y A, trimestres).
- `*.examen.json`: un archivo por examen.
- `imagenes/`: figuras recortadas del original (solo las necesarias para responder; las fotos decorativas se omiten).
  `anchoMm` es el ancho impreso en el original; las que llevan `medir: true` se imprimen siempre a tamaño real.
- `_extraccion/`: los scripts con los que se generó todo, por si hay que corregir algo y regenerar.

Notas de la extracción:
- Los enunciados se han copiado tal cual, salvo erratas evidentes.
- En el 1.er trimestre, el texto de la nota del ejercicio 2 (ventas de enero a marzo) y la medida «28 mm» del geoplano
  del modelo B estaban como WordArt y no se ven al convertir; se han sacado del XML del Word.
- En el tema 9, las cuadrículas de décimas y centésimas se han redibujado limpias (en el Word quedan tapadas por una foto).
- El modelo A del tema 9 se descuadra al abrir el Word (el ejercicio 1 pasa a otra página); el contenido está completo.
